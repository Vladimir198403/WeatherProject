package com.volodin.weatherprogect;

public interface Constants {
    String LENG = "LENG";
    String SITY = "SITY";
}
