package com.volodin.weatherprogect;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ForecastActivity extends AppCompatActivity implements Constants {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forecast);
    }
}